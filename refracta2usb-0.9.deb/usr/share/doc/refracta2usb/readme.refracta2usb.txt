refracta2usb v.07
refracta2usb allows you to create a live-USB system on a thumb drive
using a live-CD iso file or directly from a running live system. It also
allows you to replace the system on an existing live-USB drive with a
system from another iso file, so you can easily update your live system
with your latest snapshot.

Also included in this package is mkusbcrypt, which creates an encrypted,
writable /home partition, using non-standard methods for persistence.


---------------

INSTALLATION

Installation from tarball:
Unpack the tarball somewhere in your home directory and then cd to the
resulting refracta2usb directory. See readme.txt. Then run the script.

	tar -xvzf refracta2usb<version>.tar.gz
	cd refracta2usb
	bash refracta2usb
	

Installation from debian package:
	
	dpkg -i refracta2usb<version>.deb


---------------

PREPARE A USB STICK

Plug in usb stick and see what the device name is with:
	dmesg | tail
	
Do not mount the device. Do not open the device on your desktop. If you
do, you'll need to unmount it.
	
Note: If the usb stick was formatted as fat32 to begin with, you might 
be able to use it as it is. If you want a partition that's writable for
saving files, you should resize the fat32 partition to make room for the
second partition.


Run gparted (you can do this from within refracta2usb)
	Create a fat32 partition big enough to hold the image, and maybe
	enough extra for future images. (e.g. 1000 MiB) Label it if you want.
	You can optionally create a second partition at this time and format
	it to ext2. 
	
	Do not label the second partition if you plan to use an encrypted 
	/home partition. 
	
	Do label it "persistence" if you plan to use standard debian-live 
	persistence. (formerly "home-rw" or "live-rw")
	
	Apply all operations.
	Set the fat32 partition to be bootable. (Right-click, Manage Flags, boot)

Run one of the "create" options in refracta2usb.	


---------------

CREATE A LIVE-USB SYSTEM

Run refracta2usb from the System menu or from command line:

	Choose which task you'd like to do.
	
	1. Create a live-USB using files taken from a live-CD .iso file. 
	This is the normal mode. The program asks you which iso file and usb
	stick you'd like to use, mounts both the iso and the usb, copies
	files from the iso to the usb, copies syslinux files and custom 
	hooks from its own library to the usb device, and makes the usb
	bootable with syslinux.
	
	2. Create a live-USB using files taken from a running live session.
	You can do this if you don't want to install Refracta to hard drive.
	Files are copied from the running system. (/lib/live/mount/medium) 
	Burn the iso to a CD and boot into the live system. Then run
	refracta2usb and select this option.
	
	3. Update a previously prepared usb stick with a newer (or older)
	image, without reformatting the stick. Lets you choose the iso file 
	and usb device, copies files as in #1 above, but does not reinstall 
	the bootloader. If the stick already contains a /live/hooks folder, 
	hooks are preserved and not replaced with the ones from the 
	program's library. This option will also work with a device that
	uses GRUB to boot - it will preserve the existing /live/boot/grub
	folder.
	
	4. Run the partition editor (gparted or cfdisk) on the selected
	usb device.
	
	5. Edit the boot menu and add an entry to boot with Refracta
	custom hooks. The script will add the menu entry with the uuid of 
	the physical partition containing the encrypted home. For this to
	work properly, you should have already done a few things:
	
		a. You ran one of the "Create" options above and made a
		bootable live-USB.
		
		b. You created a second partition, formatted as ext2/3/4
		
		c. You booted your live-USB and as root, ran mkusbcrypt.
		
		d. You can then plug the usb stick into a running linux system,
		run refracta2usb, and select the "Edit boot menu" option.
					
	Note that this method is separate and distinct from standard
	debian-live persistence, which at this time in Debian Wheezy does 
	not handle encrypted partitions. This is a hack to get around that
	limitation. If you want standard debian-live persistence, see the 
	section on persistence below.
	
	6. (Re)install the syslinux bootloader to the partition and to the
	Master Boot Record. Use this option if you have trouble booting your
	USB device, or if you meant to set $write_to_mbr to "TRUE" when you
	ran one of the "Create" options. This saves you from having to do 
	the whole install again.
	
	7. Change default Options. See the Special Settings section below.
	
	 

SPECIAL SETTINGS

Until there is a config file, these variables can be edited at the
beginning of the script:


# If your editor is not geany, gedit, kwrite, leafpad, medit, 
# or mousepad, put the full path to the editor here (between the quotes)
# and add a command-line option if needed. Used to edit the boot menu.
other_editor=""
other_editor_option=

# Add Refracta /live/hooks to use encrypted /home
	add_hooks="TRUE"

# Save existing /live/hooks (in case you customized them and don't want
# them replaced with stock Refracta hooks.)
	save_hooks="TRUE"

# If you have a usb stick that uses GRUB instead of syslinux,
# this will save your /live/boot/grub if you update the image with 
# a newer iso.
	save_boot="TRUE"
	
# Saves your syslinux folder when you update the image with a newer iso.
# Default is "no" and the isolinux folder in the iso image is used.
	save_syslinux="FALSE"

# Copies the default syslinux folder to the usb stick instead of using
# the isolinux folder from iso file or from live-CD session, or instead 
# of the syslinux folder from a live-USB session. This is really only
# useful if you're making a live-USB from a running live-USB that uses
# the GRUB bootloader.
	copy_syslinux="FALSE"

# Write syslinux/mbr.bin to the Master Boot Record. This may be needed
# if the usb device previously had a different bootloader on it, or if
# it previously had an isohybrid image or a standard debian-live image
# that was written directly to the device using dd, cat or rawrite
# command. An alternative to this is to use the 'install-mbr' command.
	write_to_mbr="FALSE"


---------------

IF YOU HAVE TROUBLE BOOTING
(or if your usb stick previously had a different bootloader installed,
or if the stick was imaged with an isohybrid file.)

1. First try the Booloader task. You might just need to write 
syslinux/mbr.bin to the Master Boot Record. This option will do that
for you. Or, you could do it manually with the 'dd' command below.

	dd bs=440 count=1 conv=notrunc if=/usr/lib/syslinux/mbr.bin of=/dev/<sdX>



If that doesn't work...
 

2. Run gparted:
Select the correct drive from the drop-down menu in the upper right corner.
Menu bar - select Device - Create Partition Table
Create partition(s)

Run refracta2usb, and in the Options section, check the box for
"write_to_mbr" before running one of the "Create" tasks.



If that doesn't work...

3. More Drastic Measures:

Zero the beginning of the device:
	dd if=/dev/zero of=/dev/sdX bs=512 count=4096

Then go to #2 above (Run gparted, run refracta2usb with "write_to_mbr")


---------------

ALTERNATE MBR CODE
If you don't want syslinux/mbr.bin in your Master Boot Record, an
alternative is to run 'install-mbr'.

Run:
	install-mbr /dev/<sdX>	
	
If the above command results in a non-bootable device that shows only
"MBR FA:" as the prompt, and typing "1" does nothing, you might need:

	install-mbr -e 14FA /dev/<sdX>
	
You might need to unplug and re-plug in the device at this time.

Run refracta2usb and use one of the "create" options. Try booting again.
At the 14FA prompt, type the number, "1"


---------------

CREATE AN ENCRYPTED /home PARTITION

Boot into your live-USB.

You'll need to have a second partition on the usb device. Recommended
format is ext2. Don't label this partition. If you didn't create this
during the previous partitioning, do it now. 

As root, in a terminal or console, run:

	mkusbcrypt

When you reboot into the usb stick, choose the "use hooks" item from the
boot menu. Hit TAB and append the boot line with the correct lukshome
device. For example:

	lukshome=/dev/sdb


To avoid having to enter this information at every boot, you can edit
the boot menu. Shut down the live system, and plug the usb stick into a 
running system. You can either use refracta2usb and select the "Edit
boot menu" option, or you can do it manually as follows:

Check the device name with:

	dmesg | tail


Get the uuid with:

	/sbin/blkid /dev/<sdX>

Open the system volume (the fat32) and edit syslinux/live.cfg, adding
the uuid to the "use hooks" boot entry. Paste in the uuid immediately 
after "lukshome=" like this:

	label with_hooks
		menu label Refracta (use hooks)
		kernel /live/vmlinuz quiet
		append initrd=/live/initrd.img boot=live ip=frommedia union=aufs config=hooks hooks=file:///lib/live/mount/medium/live/hooks/hookscript lukshome=728B-0851728B-0851728B-0851




OPTIONAL
If you want to change the disk label that shows up on your desktop when
you mount the usb stick in a running linux system, edit the disklabel
variable inside the script. (/usr/bin/mkusbcrypt or 
/usr/local/bin/mkusbcrypt)



MANUAL METHOD (if you don't use mkusbcrypt)
	
Boot from usb into the live system. Open a root terminal. Create an
encrypted volume, open it, create a filesystem, mount it and label it if
you want. The disk label will show up on the desktop when the encrypted
volume is opened.

	cryptsetup luksFormat /dev/sdx2
	cryptsetup luksOpen /dev/sdx2 <label>
	mke2fs -t ext2 /dev/sdx2
	mount /dev/mapper/<label> /mnt
	(optional) e2label /dev/mapper/<label>  <disk-label>
	
To copy the contents of /home to the second partition, you need to drop
to console. Press ctrl-alt-F1 (or F2) and log in as root.
	/etc/init.d/lightdm stop
	rsync -av /home/ /mnt/
	
Shut down. Plug the usb stick into a running system. Get the uuid of the
encrypted volume (/dev/sdx2) with:
	/sbin/blkid

Open the system volume (the fat32) and edit syslinux/live.cfg, adding
the uuid to the "use hooks" boot entry. Paste in the uuid immediately 
after "lukshome=" like this:

	label with_hooks
		menu label Refracta (use hooks)
		kernel /live/vmlinuz quiet
		append initrd=/live/initrd.img boot=live ip=frommedia union=aufs config=hooks hooks=file:///lib/live/mount/medium/live/hooks/hookscript lukshome=728B-0851728B-0851728B-0851



STANDARD DEBIAN-LIVE PERSISTENCE

Create a second partition, formatted ext2.

Copy persistence.conf into the root of the partition. The file is set
to use a persistent /home, without having to copy the /home files in 
advance. If you want full persistence, edit the appropriate lines.
(see /usr/share/doc/refracta2usb/examples/persistence.conf)

Either edit the boot menu or manually edit the boot command line when
you're booting to add the word "persistence" to the append line.





